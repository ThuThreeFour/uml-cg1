I have used examples from this same repository for my previous assignment and this assignment.
However, I did make modifications the example codes from:
https://github.com/josdirksen/essential-threejs,
https://threejs.org/docs/#api/lights/AmbientLight,
https://threejs.org/docs/#api/lights/DirectionalLight.
