I have used examples from this same repository for my previous assignment and this assignment:
https://github.com/josdirksen/essential-threejs

and also https://threejs.org/.

Please see the report.txt for more details.